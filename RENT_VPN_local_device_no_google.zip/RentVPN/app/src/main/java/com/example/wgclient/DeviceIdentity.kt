package com.example.wgclient

import android.content.Context
import android.os.Build
import java.util.UUID

/**
 * Локальный идентификатор установки приложения.
 * Это случайный UUID, а не IMEI/серийный номер или другой аппаратный идентификатор.
 * Пока у проекта нет backend, этот ID виден только на текущем устройстве.
 */
object DeviceIdentity {
    private const val PREFS = "rent_vpn_device"
    private const val KEY_ID = "installation_id"

    fun id(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_ID, null)
        if (!existing.isNullOrBlank()) return existing

        val created = UUID.randomUUID().toString()
        prefs.edit().putString(KEY_ID, created).apply()
        return created
    }

    fun model(): String = listOf(Build.MANUFACTURER, Build.MODEL)
        .filter { it.isNotBlank() }
        .distinct()
        .joinToString(" ")
        .ifBlank { "Android-устройство" }

    fun androidVersion(): String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
}
